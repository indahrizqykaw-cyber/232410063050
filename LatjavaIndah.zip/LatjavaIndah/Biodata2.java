public class Biodata2 {
public static void main (String [] args) {
    System.out.println("============================================");
    System.out.println("|Nama    :  INDAH RIZQYKA WULANDARI        |");
	System.out.println("|NIS     :  232410063050                   |");
	System.out.println("|Alamat  :  Perum Korpri Cigintung         |");  
	System.out.println("|Email   :  Indahrizqykaw.com              |");
	System.out.println("============================================");
	}
}