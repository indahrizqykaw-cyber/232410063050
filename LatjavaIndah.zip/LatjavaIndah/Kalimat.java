public class Kalimat {
    public static void main(String [] args) {
	    // Buat Variabel
	    String subjek = "Saya ";
	    String predikat = "menulis ";
	    String objek = "program Java ";
	    String keterangan = "hari ini";
	    // Print kalimat S+P+O+K
	    System.out.println(subjek+predikat+objek+keterangan);
	}
}