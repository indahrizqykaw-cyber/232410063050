public class LatOperator {
    public static void main(String [] args) {
		int n1=10;
		int n2=15;
		int h1=n1+n2;
		int h2=(n1%4)*n2;
	    System.out.println("hasil penjumlahan ="+h1);
		System.out.println("hasil sisa bagi 4 x n2 ="+h2);	
	}
}