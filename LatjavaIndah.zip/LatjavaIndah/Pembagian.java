public class Pembagian {
    public static void main(String [] args) {
	    int a = 20;
		int b = 8;
		int hasilBagi = a / b;
		// Lengkapilah kode pada baris int
		System.out.println("A = " + a);
		System.out.println("B = " + b);
		System.out.println("A dibagi B = " + hasilBagi);
	}
}