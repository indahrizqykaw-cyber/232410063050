public class Salam {
public static void main (String [] arga) {
        System.out.println ("Assalammu'alaikum");}
	}