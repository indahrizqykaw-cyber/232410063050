public class Salam2 {
    public static void main(String [] args) {
	    // buat karakter
		char c1 = 'S';
		char c2 = 'A';
		char c3 = 'L';
		char c4 = 'A';
		char c5 = 'M';
		// Print
		System.out.println(""+c1+c2+c3+c4+c5);
		System.out.println(""+c5+c4+c3+c2+c1);
	}
}