public class SalamNama {
    public static void main(String [] args) {String nama
	    = "Fathiah";
		Syatem.out.println("Assalammu'alaikum" + nama);
	}
}