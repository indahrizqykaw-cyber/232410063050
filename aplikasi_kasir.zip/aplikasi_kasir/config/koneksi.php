<?php
// config/koneksi.php

// Konfigurasi database
$host = "localhost";      // nama host, biasanya localhost
$user = "root";           // username database
$password = "";           // password database
$database = "db_kasir";   // nama database

// Buat koneksi
$koneksi = mysqli_connect($host, $user, $password, $database);

// Cek koneksi
if (!$koneksi) {
    // Jika gagal koneksi, hentikan eksekusi dan tampilkan pesan error
    die("❌ Koneksi database gagal: " . mysqli_connect_error());
}

// Koneksi berhasil → tidak ada echo atau tulisan apa pun
?>
