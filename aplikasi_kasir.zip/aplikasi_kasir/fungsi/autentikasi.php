<?php
// Mulai session hanya kalau belum aktif
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Fungsi untuk cek login user
 */
function cekLogin() {
    if (!isset($_SESSION['Username']) || !isset($_SESSION['Level'])) {
        // Kalau belum login, arahkan ke halaman login
        header("Location: ../login.php");
        exit;
    }
}
