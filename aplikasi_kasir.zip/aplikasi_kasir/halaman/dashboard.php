<?php 
session_start();
include '../fungsi/autentikasi.php';
cekLogin();
include '../config/koneksi.php';

// Query jumlah produk
$q_produk = mysqli_query($koneksi, "SELECT COUNT(*) AS jumlah_produk FROM produk");
if (!$q_produk) {
    die("Query gagal: " . mysqli_error($koneksi));
}
$row_produk = mysqli_fetch_assoc($q_produk);
$jumlah_produk = $row_produk['jumlah_produk'];

// Query total transaksi hari ini
$q_transaksi = mysqli_query($koneksi, "
    SELECT IFNULL(SUM(TotalHarga), 0) AS total_transaksi
    FROM penjualan
    WHERE TanggalPenjualan = CURDATE()
");
if (!$q_transaksi) {
    die("Query gagal: " . mysqli_error($koneksi));
}
$row_transaksi = mysqli_fetch_assoc($q_transaksi);
$total_transaksi = $row_transaksi['total_transaksi'];

include '../templates/header.php';
?>

<style>
body {
    background: linear-gradient(to bottom, #87CEEB, #1E3C72);
    min-height: 100vh;
    font-family: 'Poppins', sans-serif;
}

/* Animasi fade-in */
.fade-in {
    animation: fadeIn 1s ease-in-out;
}
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}

/* Card putih transparan */
.dashboard-card {
    background: rgba(255, 255, 255, 0.85);
    border-radius: 1.2rem;
    backdrop-filter: blur(12px);
    box-shadow: 0 4px 20px rgba(0,0,0,0.15);
    transition: all 0.3s ease-in-out;
}
.dashboard-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.25);
}

/* Ikon */
.dashboard-icon {
    font-size: 3.2rem;
    margin-bottom: 15px;
    color: #1E3C72;
    transition: 0.3s ease;
}
.dashboard-card:hover .dashboard-icon {
    transform: scale(1.15);
    color: #003366;
}

/* Angka gradient */
.gradient-text {
    background: linear-gradient(45deg, #1E3C72, #87CEEB);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

/* Tombol biru tua */
.btn-soft {
    background: #1E3C72;
    color: #fff;
    font-weight: 600;
    border: none;
    transition: all 0.3s;
    border-radius: 50px;
}
.btn-soft:hover {
    background: #003366;
    color: #fff;
}
</style>

<div class="container py-5 fade-in">
    <div class="text-center text-white mb-5">
        <h1 class="fw-bold">
            Selamat datang, 
            <?= isset($_SESSION['Username']) ? htmlspecialchars($_SESSION['Username']) : 'Pengguna'; ?>!
        </h1>
        <p class="fs-5">
            Anda login sebagai: 
            <strong><?= isset($_SESSION['Level']) ? htmlspecialchars($_SESSION['Level']) : 'Tidak diketahui'; ?></strong>
        </p>
    </div>

    <div class="row g-4">
        <!-- Card Jumlah Produk -->
        <div class="col-md-6">
            <div class="card dashboard-card text-center p-4 fade-in">
                <div class="card-body">
                    <i class="bi bi-box-seam dashboard-icon"></i>
                    <h5 class="card-title">Jumlah Produk</h5>
                    <p class="display-4 fw-bold gradient-text"><?= $jumlah_produk; ?></p>
                    <a href="produk.php" class="btn btn-soft px-4 shadow-sm">Lihat Detail</a>
                </div>
            </div>
        </div>

        <!-- Card Total Transaksi -->
        <div class="col-md-6">
            <div class="card dashboard-card text-center p-4 fade-in" style="animation-delay: 0.2s;">
                <div class="card-body">
                    <i class="bi bi-cash-stack dashboard-icon"></i>
                    <h5 class="card-title">Total Transaksi Hari Ini</h5>
                    <p class="display-4 fw-bold gradient-text">Rp <?= number_format($total_transaksi, 0, ',', '.'); ?></p>
                    <a href="penjualan.php" class="btn btn-soft px-4 shadow-sm">Lihat Detail</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../templates/footer.php'; ?>
