<?php
include '../fungsi/autentikasi.php';
cekLogin();
if ($_SESSION['Level'] != 'administrator') {
    header('Location: produk.php');
    exit;
}
include '../config/koneksi.php';

// Ambil data produk berdasarkan ID
$id_produk = $_GET['id'];
$query = "SELECT * FROM produk WHERE ProdukID = $id_produk";
$result = mysqli_query($koneksi, $query);
$data_produk = mysqli_fetch_assoc($result);

include '../templates/header.php';
?>

<style>
body {
    background: linear-gradient(to right, #a2d9ff, #004e92);
    min-height: 100vh;
    font-family: "Segoe UI", sans-serif;
}
.card-custom {
    border-radius: 12px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.2);
}
.card-header-custom {
    background: linear-gradient(90deg, #004e92, #007aff);
    color: #fff;
    font-weight: bold;
}
.btn-gradient {
    background: linear-gradient(135deg, #00c6ff, #0072ff);
    color: #fff;
    border: none;
}
.btn-gradient:hover {
    background: linear-gradient(135deg, #0072ff, #00c6ff);
    color: #fff;
}
</style>

<div class="container py-5">
    <div class="card card-custom">
        <div class="card-header card-header-custom">
            <i class="bi bi-box-seam"></i> Edit Produk
        </div>
        <div class="card-body bg-light">
            <form action="../proses/proses_edit_produk.php" method="POST">
                <input type="hidden" name="id" value="<?= $data_produk['ProdukID']; ?>">
                
                <div class="mb-3">
                    <label for="nama_produk" class="form-label">Nama Produk</label>
                    <input type="text" class="form-control" id="nama_produk" name="nama_produk" value="<?= $data_produk['NamaProduk']; ?>" required>
                </div>
                
                <div class="mb-3">
                    <label for="harga" class="form-label">Harga</label>
                    <input type="number" class="form-control" id="harga" name="harga" value="<?= $data_produk['Harga']; ?>" required>
                </div>
                
                <div class="mb-3">
                    <label for="stok" class="form-label">Stok</label>
                    <input type="number" class="form-control" id="stok" name="stok" value="<?= $data_produk['Stok']; ?>" required>
                </div>
                
                <button type="submit" class="btn btn-gradient"><i class="bi bi-save"></i> Simpan Perubahan</button>
                <a href="produk.php" class="btn btn-secondary"><i class="bi bi-x-circle"></i> Batal</a>
            </form>
        </div>
    </div>
</div>

<?php include '../templates/footer.php'; ?>
