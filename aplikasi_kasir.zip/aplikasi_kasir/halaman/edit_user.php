<?php
include '../fungsi/autentikasi.php';
cekLogin();
if ($_SESSION['Level'] != 'administrator') {
    header('Location: user.php');
    exit;
}
include '../config/koneksi.php';

$id_user = $_GET['id'];
$query = "SELECT UserID, Username, Level FROM user WHERE UserID = $id_user";
$result = mysqli_query($koneksi, $query);
$data_user = mysqli_fetch_assoc($result);

include '../templates/header.php';
?>

<style>
    body {
        background: linear-gradient(to right, #a2d9ff, #004e92);
        min-height: 100vh;
        font-family: "Segoe UI", sans-serif;
    }
    .card-custom {
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0 8px 20px rgba(0,0,0,0.2);
    }
    .card-header-custom {
        background: linear-gradient(90deg, #004e92, #00c6ff);
        color: #fff;
        font-weight: bold;
        font-size: 1.3rem;
    }
    .btn-gradient {
        background: linear-gradient(135deg, #00c6ff, #0072ff);
        color: #fff;
        border: none;
    }
    .btn-gradient:hover {
        background: linear-gradient(135deg, #0072ff, #00c6ff);
        color: #fff;
    }
</style>

<div class="container py-5">
    <div class="card card-custom mx-auto" style="max-width: 600px;">
        <div class="card-header card-header-custom text-center">
            <i class="bi bi-pencil-square"></i> Edit User
        </div>
        <div class="card-body bg-light">
            <form action="../proses/proses_edit_user.php" method="POST">
                <input type="hidden" name="id" value="<?= $data_user['UserID']; ?>">

                <div class="mb-3">
                    <label for="username" class="form-label fw-bold">Username</label>
                    <input type="text" class="form-control" id="username" name="username" value="<?= $data_user['Username']; ?>" required>
                </div>

                <div class="mb-3">
                    <label for="level" class="form-label fw-bold">Level</label>
                    <select class="form-select" id="level" name="level" required>
                        <option value="administrator" <?= ($data_user['Level'] == 'administrator') ? 'selected' : ''; ?>>Administrator</option>
                        <option value="petugas" <?= ($data_user['Level'] == 'petugas') ? 'selected' : ''; ?>>Petugas</option>
                    </select>
                </div>

                <div class="d-flex justify-content-between mt-4">
                    <a href="user.php" class="btn btn-secondary w-45">Batal</a>
                    <button type="submit" class="btn btn-gradient w-45">💾 Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../templates/footer.php'; ?>
