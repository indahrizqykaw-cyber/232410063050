<?php
include '../fungsi/autentikasi.php';
cekLogin();
include '../config/koneksi.php';

// Ambil data produk
$query_produk = "SELECT ProdukID, NamaProduk, Harga, Stok FROM produk WHERE Stok > 0";
$result_produk = mysqli_query($koneksi, $query_produk);

// Ambil data pelanggan
$query_pelanggan = "SELECT PelangganID, NamaPelanggan FROM pelanggan WHERE PelangganID != 1";
$result_pelanggan = mysqli_query($koneksi, $query_pelanggan);

include '../templates/header.php';
?>

<style>
body {
    background: linear-gradient(to right, #6fb1fc, #1e3c72);
    min-height: 100vh;
    font-family: "Segoe UI", sans-serif;
}
.card-custom {
    border-radius: 15px;
    overflow: hidden;
    box-shadow: 0px 8px 18px rgba(0,0,0,0.2);
}
.card-header {
    background: linear-gradient(135deg, #1e3c72, #2a5298);
    color: #fff;
}
.btn-primary {
    background: linear-gradient(135deg, #1e3c72, #2a5298);
    border: none;
}
.btn-primary:hover {
    background: linear-gradient(135deg, #2a5298, #1e3c72);
}
.btn-success {
    background: linear-gradient(135deg, #00c6ff, #0072ff);
    border: none;
}
.btn-success:hover {
    background: linear-gradient(135deg, #0072ff, #00c6ff);
}
table thead {
    background: linear-gradient(135deg, #1e3c72, #2a5298);
    color: #fff;
}
/* Notifikasi */
.alert-custom {
    padding: 12px;
    border-radius: 8px;
    margin-bottom: 15px;
    display: none;
    font-weight: 600;
    text-align: center;
}
.alert-error {
    background: #ffcccc;
    color: #b30000;
    border: 1px solid #ff4d4d;
}
</style>

<div class="container py-5">

    <!-- Tombol Kembali -->
    <div class="mb-3">
        <a href="dashboard.php" class="btn btn-primary shadow-sm">
            <i class="bi bi-arrow-left-circle"></i> Kembali
        </a>
    </div>

    <div class="card card-custom">
        <div class="card-header text-center">
            <h2 class="mb-0">🛒 Transaksi Penjualan</h2>
        </div>
        <div class="card-body bg-light">

            <!-- Notifikasi -->
            <?php if (isset($_GET['status']) && $_GET['status'] == 'success'): ?>
                <div class="alert alert-success fw-bold text-center" style="border-radius:12px;">
                    🎉 Transaksi berhasil disimpan!
                </div>
            <?php endif; ?>

            <!-- Placeholder untuk notifikasi error JS -->
            <div id="notif" class="alert-custom alert-error"></div>

            <form action="../proses/proses_penjualan.php" method="POST">
                <!-- Pilih Pelanggan -->
                <div class="mb-3">
                    <label for="pelanggan_id" class="form-label fw-bold">👤 Pilih Pelanggan</label>
                    <select name="pelanggan_id" class="form-select">
                        <option value="1" selected>-- Pilih Pelanggan --</option>
                        <?php while ($row_pelanggan = mysqli_fetch_assoc($result_pelanggan)): ?>
                            <option value="<?= htmlspecialchars($row_pelanggan['PelangganID']); ?>">
                                <?= htmlspecialchars($row_pelanggan['NamaPelanggan']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <hr>

                <!-- Pilih Barang -->
                <h4 class="fw-bold mb-3 text-primary">📦 Pilih Barang</h4>
                <div class="row g-3 mb-3">
                    <div class="col-md-5">
                        <label for="produk_input" class="form-label">Produk</label>
                        <select id="produk_input" class="form-select">
                            <option value="">-- Pilih Produk --</option>
                            <?php mysqli_data_seek($result_produk, 0); ?>
                            <?php while ($row_produk = mysqli_fetch_assoc($result_produk)): ?>
                                <option value="<?= htmlspecialchars($row_produk['ProdukID']); ?>"
                                    data-harga="<?= htmlspecialchars($row_produk['Harga']); ?>"
                                    data-nama="<?= htmlspecialchars($row_produk['NamaProduk']); ?>"
                                    data-stok="<?= htmlspecialchars($row_produk['Stok']); ?>">
                                    <?= htmlspecialchars($row_produk['NamaProduk']); ?> (Stok: <?= htmlspecialchars($row_produk['Stok']); ?>)
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label for="jumlah_input" class="form-label">Jumlah</label>
                        <input type="number" id="jumlah_input" class="form-control" min="1" value="1">
                    </div>
                    <div class="col-md-4 d-flex align-items-end">
                        <button type="button" class="btn btn-primary w-100 fw-bold" id="tambah-keranjang">
                            ➕ Tambah ke Keranjang
                        </button>
                    </div>
                </div>

                <hr>

                <!-- Keranjang Belanja -->
                <h4 class="fw-bold mb-3 text-primary">🧾 Keranjang Belanja</h4>
                <div class="table-responsive">
                    <table class="table table-bordered table-hover text-center align-middle">
                        <thead>
                            <tr>
                                <th>Produk</th>
                                <th>Harga</th>
                                <th>Jumlah</th>
                                <th>Subtotal</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody id="keranjang-body"></tbody>
                        <tfoot>
                            <tr>
                                <td colspan="3" class="text-end fw-bold">Total Harga</td>
                                <td colspan="2" class="fw-bold fs-5 text-success" id="total-harga-display">Rp 0</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>

                <div id="keranjang-inputs"></div>
                <input type="hidden" name="total_harga" id="total_harga">

                <div class="d-grid mt-4 gap-2">
                    <button type="submit" class="btn btn-primary btn-lg fw-bold" id="simpan-transaksi" disabled>
                        💾 Simpan Transaksi
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- SCRIPT KERANJANG -->
<script>
document.addEventListener("DOMContentLoaded", function () {
    const produkSelect = document.getElementById("produk_input");
    const jumlahInput = document.getElementById("jumlah_input");
    const tambahBtn = document.getElementById("tambah-keranjang");
    const keranjangBody = document.getElementById("keranjang-body");
    const totalDisplay = document.getElementById("total-harga-display");
    const totalInput = document.getElementById("total_harga");
    const simpanBtn = document.getElementById("simpan-transaksi");
    const keranjangInputs = document.getElementById("keranjang-inputs");
    const notif = document.getElementById("notif");

    let keranjang = [];

    function showNotif(pesan) {
        notif.textContent = pesan;
        notif.style.display = "block";
        setTimeout(() => {
            notif.style.display = "none";
        }, 3000);
    }

    tambahBtn.addEventListener("click", function () {
        const selected = produkSelect.options[produkSelect.selectedIndex];
        const produkID = selected.value;
        const namaProduk = selected.getAttribute("data-nama");
        const harga = parseInt(selected.getAttribute("data-harga"));
        const stok = parseInt(selected.getAttribute("data-stok"));
        const jumlah = parseInt(jumlahInput.value);

        if (!produkID) {
            showNotif("⚠️ Pilih produk dulu!");
            return;
        }
        if (jumlah < 1) {
            showNotif("⚠️ Jumlah minimal 1");
            return;
        }
        if (jumlah > stok) {
            showNotif("⚠️ Stok tidak cukup!");
            return;
        }

        let existing = keranjang.find(item => item.id === produkID);
        if (existing) {
            if (existing.jumlah + jumlah > stok) {
                showNotif("⚠️ Stok tidak cukup!");
                return;
            }
            existing.jumlah += jumlah;
        } else {
            keranjang.push({ id: produkID, nama: namaProduk, harga: harga, jumlah: jumlah });
        }

        renderKeranjang();
    });

    function renderKeranjang() {
        keranjangBody.innerHTML = "";
        keranjangInputs.innerHTML = "";
        let total = 0;

        keranjang.forEach((item, index) => {
            let subtotal = item.harga * item.jumlah;
            total += subtotal;

            keranjangBody.innerHTML += `
                <tr>
                    <td>${item.nama}</td>
                    <td>Rp ${item.harga.toLocaleString()}</td>
                    <td>${item.jumlah}</td>
                    <td>Rp ${subtotal.toLocaleString()}</td>
                    <td><button type="button" class="btn btn-danger btn-sm" onclick="hapusItem(${index})">❌ Hapus</button></td>
                </tr>
            `;
            keranjangInputs.innerHTML += `
                <input type="hidden" name="produk_id[]" value="${item.id}">
                <input type="hidden" name="jumlah[]" value="${item.jumlah}">
            `;
        });

        totalDisplay.textContent = "Rp " + total.toLocaleString();
        totalInput.value = total;
        simpanBtn.disabled = keranjang.length === 0;
    }

    window.hapusItem = function (index) {
        keranjang.splice(index, 1);
        renderKeranjang();
    }
});
</script>

<?php include '../templates/footer.php'; ?>
