<?php
include '../fungsi/autentikasi.php';
cekLogin();
include '../config/koneksi.php';

// Ambil kata kunci pencarian
$search_query = isset($_GET['search']) ? $_GET['search'] : '';

$query = "SELECT ProdukID, NamaProduk, Harga, Stok FROM produk";
if (!empty($search_query)) {
    $query .= " WHERE NamaProduk LIKE '%" . mysqli_real_escape_string($koneksi, $search_query) . "%'";
}
$result = mysqli_query($koneksi, $query);

include '../templates/header.php';
?>

<style>
body {
    background: linear-gradient(to right, #6eb6f7, #1a73e8);
    min-height: 100vh;
    font-family: "Segoe UI", sans-serif;
}

/* Button kembali */
.btn-kembali {
    background: #1976d2;
    border: none;
    padding: 8px 16px;
    border-radius: 10px;
    font-weight: 600;
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    display: inline-flex;
    align-items: center;
    gap: 6px;
    text-decoration: none;
    color: #fff;
    margin-bottom: 20px;
    transition: 0.2s;
}
.btn-kembali:hover {
    background: #1565c0;
    color: #fff;
}

/* Judul */
h2 {
    color: white;
    font-weight: bold;
    text-align: center;
    margin-bottom: 25px;
}

/* Card utama */
.card-custom {
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
    overflow: hidden;
    padding: 20px;
}

/* Header tabel */
.table thead tr th {
    background: #1976d2;
    color: #fff;
    text-align: center;
    font-weight: 600;
}

/* Isi tabel */
.table tbody tr:hover {
    background: #f1faff;
}

.table td, .table th {
    vertical-align: middle;
    text-align: center;
}

/* Tombol */
.btn-primary {
    background: linear-gradient(to right, #1976d2, #1565c0);
    border: none;
    border-radius: 8px;
    font-weight: 600;
    padding: 8px 15px;
}

.btn-warning {
    background: #ffc107;
    border: none;
    font-weight: 600;
    color: #000;
    padding: 6px 12px;
    border-radius: 6px;
}

.btn-danger {
    background: #e53935;
    border: none;
    font-weight: 600;
    color: #fff;
    padding: 6px 12px;
    border-radius: 6px;
}

.btn-cari {
    background: linear-gradient(to right, #1976d2, #1565c0);
    border: none;
    border-radius: 8px;
    font-weight: 600;
    color: #fff;
}

/* Badge stok */
.badge-stok {
    background: #03a9f4;
    color: #fff;
    padding: 6px 12px;
    border-radius: 12px;
    font-weight: bold;
}

/* Alert */
.alert {
    border-radius: 10px;
    font-weight: 500;
}
</style>

<div class="container py-4">

    <?php
    if (isset($_GET['pesan'])) {
        if ($_GET['pesan'] == 'sukses') {
            echo '<div class="alert alert-success">✅ Data produk berhasil disimpan!</div>';
        } elseif ($_GET['pesan'] == 'edit_sukses') {
            echo '<div class="alert alert-success">✏️ Data produk berhasil diperbarui!</div>';
        } elseif ($_GET['pesan'] == 'hapus_sukses') {
            echo '<div class="alert alert-success">🗑️ Data produk berhasil dihapus!</div>';
        }
    }
    ?>

    <h2>📦 Manajemen Produk</h2>

    <!-- Tombol kembali (sekarang posisinya di bawah judul dan di atas tabel) -->
    <div class="text-start mb-3">
        <a href="dashboard.php" class="btn btn-primary shadow-sm"><i class="bi bi-arrow-left-circle"></i> Kembali</a>
        </a>
    </div>

    <div class="card-custom">
        <div class="row mb-3">
            <div class="col-md-6">
                <?php if ($_SESSION['Level'] == 'administrator'): ?>
                    <a href="tambah_produk.php" class="btn btn-primary"><i class="bi bi-plus-circle"></i> Tambah Produk</a>
                <?php endif; ?>
            </div>
            <div class="col-md-6">
                <form action="" method="GET" class="d-flex">
                    <input class="form-control me-2" type="search" placeholder="Cari produk..." name="search" value="<?= htmlspecialchars($search_query); ?>">
                    <button class="btn btn-cari" type="submit"><i class="bi bi-search"></i> Cari</button>
                </form>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-bordered table-striped align-middle">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Produk</th>
                        <th>Harga</th>
                        <th>Stok</th>
                        <?php if ($_SESSION['Level'] == 'administrator'): ?>
                            <th>Aksi</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    while ($row = mysqli_fetch_assoc($result)):
                    ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= $row['NamaProduk']; ?></td>
                            <td>Rp <?= number_format($row['Harga'], 0, ',', '.'); ?></td>
                            <td><span class="badge-stok"><?= $row['Stok']; ?></span></td>
                            <?php if ($_SESSION['Level'] == 'administrator'): ?>
                                <td>
                                    <a href="edit_produk.php?id=<?= $row['ProdukID']; ?>" class="btn btn-warning btn-sm"><i class="bi bi-pencil-square"></i> Edit</a>
                                    <a href="../proses/proses_hapus_produk.php?id=<?= $row['ProdukID']; ?>" class="btn btn-danger btn-sm"><i class="bi bi-trash"></i> Hapus</a>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../templates/footer.php'; ?>
