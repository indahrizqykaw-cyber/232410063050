<?php
include '../fungsi/autentikasi.php';
cekLogin();
if ($_SESSION['Level'] != 'administrator') {
    header('Location: user.php');
    exit;
}
include '../config/koneksi.php';
include '../templates/header.php';
?>

<style>
    body {
        background: linear-gradient(to right, #a2d9ff, #004e92);
        font-family: "Segoe UI", sans-serif;
        min-height: 100vh;
    }
    .card-custom {
        border-radius: 12px;
        box-shadow: 0 8px 20px rgba(0,0,0,0.2);
        overflow: hidden;
    }
    .card-header-custom {
        background: linear-gradient(90deg, #004e92, #007aff);
        color: #fff;
        font-weight: bold;
    }
    .btn-gradient {
        background: linear-gradient(135deg, #00c6ff, #0072ff);
        color: #fff;
        border: none;
    }
    .btn-gradient:hover {
        background: linear-gradient(135deg, #0072ff, #00c6ff);
        color: #fff;
    }
</style>

<div class="container py-5">
    <div class="card card-custom mx-auto" style="max-width: 500px;">
        <div class="card-header card-header-custom">
            <i class="bi bi-person-plus"></i> Tambah User
        </div>
        <div class="card-body bg-light">
            <form action="../proses/proses_tambah_user.php" method="POST">
                <div class="mb-3">
                    <label for="username" class="form-label fw-bold">Username</label>
                    <input type="text" class="form-control" id="username" name="username" placeholder="Masukkan username" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label fw-bold">Password</label>
                    <input type="password" class="form-control" id="password" name="password" placeholder="Masukkan password" required>
                </div>
                <div class="mb-3">
                    <label for="level" class="form-label fw-bold">Level</label>
                    <select class="form-select" id="level" name="level" required>
                        <option value="">-- Pilih Level --</option>
                        <option value="administrator">Administrator</option>
                        <option value="petugas">Petugas</option>
                    </select>
                </div>
                <div class="d-flex justify-content-between">
                    <button type="submit" class="btn btn-gradient fw-bold"><i class="bi bi-save"></i> Simpan</button>
                    <a href="user.php" class="btn btn-secondary fw-bold"><i class="bi bi-x-circle"></i> Batal</a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../templates/footer.php'; ?>
