<?php
include '../fungsi/autentikasi.php';
cekLogin();
if ($_SESSION['Level'] != 'administrator') {
    header('Location: dashboard.php');
    exit;
}
include '../config/koneksi.php';

// Ambil data user
$query = "SELECT UserID, Username, Level FROM user";
$result = mysqli_query($koneksi, $query);

include '../templates/header.php';
?>

<style>
    body {
        background: linear-gradient(to right, #a2d9ff, #004e92);
        min-height: 100vh;
        font-family: "Segoe UI", sans-serif;
    }
    .card-custom {
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0 8px 20px rgba(0,0,0,0.2);
    }
    .card-header-custom {
        background: linear-gradient(90deg, #004e92, #007aff);
        color: #fff;
        font-weight: bold;
    }
    .btn-gradient {
        background: linear-gradient(135deg, #00c6ff, #0072ff);
        color: #fff;
        border: none;
    }
    .btn-gradient:hover {
        background: linear-gradient(135deg, #0072ff, #00c6ff);
        color: #fff;
    }
</style>

<div class="container py-5">
    <div class="d-flex justify-content-between mb-3">
        <a href="dashboard.php" class="btn btn-primary shadow-sm"><i class="bi bi-arrow-left-circle"></i> Kembali</a>
        <a href="tambah_user.php" class="btn btn-primary shadow-sm"><i class="bi bi-person-plus"></i> Tambah User</a>
    </div>

    <div class="card card-custom">
        <div class="card-header card-header-custom">
            <i class="bi bi-people-fill"></i> Daftar User
        </div>
        <div class="card-body bg-light">
            <div class="table-responsive">
                <table class="table table-hover table-bordered align-middle text-center">
                    <thead class="table-primary">
                        <tr>
                            <th>No</th>
                            <th>Username</th>
                            <th>Level</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; while($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?= $no++; ?></td>
                                <td><?= $row['Username']; ?></td>
                                <td><span class="badge bg-info text-dark"><?= ucfirst($row['Level']); ?></span></td>
                                <td>
                                    <!-- Tombol Edit -->
                                    <a href="edit_user.php?id=<?= $row['UserID']; ?>" class="btn btn-warning btn-sm">
                                        <i class="bi bi-pencil-square"></i> Edit
                                    </a>

                                    <!-- Tombol Hapus Langsung (POST Form) -->
                                    <form action="../proses/proses_hapus_user.php" method="POST" style="display:inline;">
                                        <input type="hidden" name="id_user" value="<?= $row['UserID']; ?>">
                                        <button type="submit" class="btn btn-danger btn-sm">
                                            <i class="bi bi-trash"></i> Hapus
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include '../templates/footer.php'; ?>
