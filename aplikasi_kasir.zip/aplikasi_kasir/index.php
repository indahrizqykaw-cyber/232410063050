<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Halaman Aplikasi Kasir</title>
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

  <style>
    body {
      /* Gradasi biru muda ke biru tua */
      background: linear-gradient(to bottom, #ccd4daff, #2d75bdff);
      height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      font-family: Arial, sans-serif;
    }

    /* Judul di luar card */
    .page-title {
      text-align: center;
      color: #003366;
      font-size: 2rem;
      font-weight: bold;
      margin-bottom: 20px;
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .page-title i {
      font-size: 2.2rem;
      color: #003366;
    }

    .card {
      width: 100%;
      max-width: 420px;
      border-radius: 15px;
      box-shadow: 0 6px 20px rgba(0,0,0,0.25);
      background: #ffffff;
    }

    .card-body {
      padding: 2rem;
    }

    .form-label {
      font-weight: 600;
      color: #333;
    }

    .btn-custom {
      background-color: #003366; /* biru tua */
      color: #fff;
      font-weight: bold;
      border-radius: 8px;
      transition: 0.3s;
    }

    .btn-custom:hover {
      background-color: #2c5782ff; /* biru tua lebih gelap */
    }

    /* Show/hide password icon */
    .input-group-text {
      cursor: pointer;
    }
  </style>
</head>
<body>
  <!-- Judul di luar card -->
  <div class="page-title">
    <i class="fa-solid fa-cash-register"></i> Login Aplikasi Kasir
  </div>

  <div class="card">
    <div class="card-body">
      <form action="proses/proses_login.php" method="post">
        <!-- Pilihan login sebagai -->
        <div class="form-group mb-3">
          <label for="role" class="form-label">Login sebagai</label>
          <select id="role" name="role" class="form-control" required>
            <option value="">-- Pilih --</option>
            <option value="admin">Admin</option>
            <option value="user">Petugas</option>
          </select>
        </div>

        <!-- Username -->
        <div class="form-group mb-3">
          <label for="username" class="form-label">Username</label>
          <input type="text" id="username" class="form-control" name="username" required>
        </div>

        <!-- Password + show/hide -->
        <div class="form-group mb-4">
          <label for="password" class="form-label">Password</label>
          <div class="input-group">
            <input type="password" id="password" class="form-control" name="password" required>
            <span class="input-group-text" onclick="togglePassword()">
              <i class="fa-solid fa-eye" id="eyeIcon"></i>
            </span>
          </div>
        </div>

        <!-- Tombol login -->
        <div>
          <button type="submit" class="btn btn-custom btn-block w-100">
            <i class="fa-solid fa-right-to-bracket"></i> Login
          </button>
        </div>
      </form>

      <!-- Tambahan link daftar -->
      <div class="text-center mt-3">
        <p>Belum punya akun? <a href="register.php" class="text-primary">Daftar</a></p>
      </div>
    </div>
  </div>

  <script>
    function togglePassword() {
      const password = document.getElementById("password");
      const eyeIcon = document.getElementById("eyeIcon");
      if (password.type === "password") {
        password.type = "text";
        eyeIcon.classList.remove("fa-eye");
        eyeIcon.classList.add("fa-eye-slash");
      } else {
        password.type = "password";
        eyeIcon.classList.remove("fa-eye-slash");
        eyeIcon.classList.add("fa-eye");
      }
    }
  </script>
</body>
</html>
