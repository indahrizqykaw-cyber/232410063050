<?php
include '../config/koneksi.php'; // pastikan path ini benar

if (isset($_GET['id'])) {
    $id_produk = (int) $_GET['id']; // pastikan tipe integer

    $query = "DELETE FROM produk WHERE ProdukID = $id_produk";

    if (mysqli_query($koneksi, $query)) {
        // langsung redirect ke halaman produk
        header('Location: ../halaman/produk.php?pesan=hapus_sukses');
        exit;
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }
} else {
    // jika tidak ada id, langsung balik ke halaman produk
    header('Location: ../halaman/produk.php');
    exit;
}
?>
