<?php
include '../config/koneksi.php';

if (isset($_GET['id'])) {
    $id_produk = (int) $_GET['id'];

    $query = "DELETE FROM produk WHERE ProdukID = $id_produk";

    if (mysqli_query($koneksi, $query)) {
        // Langsung redirect dengan pesan sukses
        header('Location: ../halaman/produk.php?pesan=hapus_sukses');
        exit;
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }
} else {
    header('Location: ../halaman/produk.php');
    exit;
}
?>
