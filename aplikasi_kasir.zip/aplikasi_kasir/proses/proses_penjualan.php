<?php
session_start();
include '../config/koneksi.php';

// Pastikan form dikirim
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pelanggan_id = $_POST['pelanggan_id'];
    $total_harga = $_POST['total_harga'];
    $produk_id   = $_POST['produk_id'];
    $jumlah      = $_POST['jumlah'];

    // Ambil UserID dari session login
    $user_id = isset($_SESSION['UserID']) ? $_SESSION['UserID'] : 1;

    // 1. Insert ke tabel penjualan (sementara TotalHarga = 0)
    $query_penjualan = "
        INSERT INTO penjualan (TanggalPenjualan, TotalHarga, PelangganID, UserID)
        VALUES (CURDATE(), 0, '$pelanggan_id', '$user_id')
    ";
    mysqli_query($koneksi, $query_penjualan);

    // Ambil ID penjualan terbaru
    $penjualan_id = mysqli_insert_id($koneksi);

    $grand_total = 0;

    // 2. Loop semua produk yg dibeli
    foreach ($produk_id as $index => $id_produk) {
        $jml = $jumlah[$index];

        // Ambil data harga & stok produk
        $q_produk = mysqli_query($koneksi, "SELECT Harga, Stok FROM produk WHERE ProdukID='$id_produk'");
        $produk = mysqli_fetch_assoc($q_produk);

        $harga = $produk['Harga'];
        $stok  = $produk['Stok'];
        $subtotal = $harga * $jml;
        $grand_total += $subtotal;

        // Simpan detail penjualan
        $query_detail = "
            INSERT INTO detailpenjualan (PenjualanID, ProdukID, JumlahProduk, Subtotal)
            VALUES ('$penjualan_id', '$id_produk', '$jml', '$subtotal')
        ";
        mysqli_query($koneksi, $query_detail);

        // Update stok produk
        $stok_baru = $stok - $jml;
        mysqli_query($koneksi, "UPDATE produk SET Stok='$stok_baru' WHERE ProdukID='$id_produk'");
    }

    // 3. Update total harga di tabel penjualan
    mysqli_query($koneksi, "
        UPDATE penjualan SET TotalHarga='$grand_total'
        WHERE PenjualanID='$penjualan_id'
    ");

    // Redirect ke halaman penjualan dengan pesan sukses
    header("Location: ../halaman/penjualan.php?status=success");
    exit;
} else {
    header("Location: ../halaman/penjualan.php?status=error");
    exit;
}
?>
