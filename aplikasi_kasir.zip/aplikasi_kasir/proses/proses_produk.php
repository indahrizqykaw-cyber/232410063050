<?php
include '../config/koneksi.php';

// Cek apakah form dikirim
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    // Cek apakah ini untuk edit atau tambah
    $id_produk = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $nama_produk = mysqli_real_escape_string($koneksi, $_POST['nama_produk']);
    $harga = (float)$_POST['harga'];
    $stok = (int)$_POST['stok'];

    if ($id_produk > 0) {
        // Update produk
        $query = "UPDATE produk SET NamaProduk = '$nama_produk', Harga = $harga, Stok = $stok WHERE ProdukID = $id_produk";
        $aksi = 'edit_sukses';
    } else {
        // Tambah produk baru
        $query = "INSERT INTO produk (NamaProduk, Harga, Stok) VALUES ('$nama_produk', $harga, $stok)";
        $aksi = 'sukses';
    }

    if (mysqli_query($koneksi, $query)) {
        // Redirect ke halaman produk setelah berhasil
        header("Location: ../halaman/produk.php?pesan=$aksi");
        exit;
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }

} else {
    // Kalau bukan POST, langsung balik ke halaman produk
    header('Location: ../halaman/produk.php');
    exit;
}
?>
