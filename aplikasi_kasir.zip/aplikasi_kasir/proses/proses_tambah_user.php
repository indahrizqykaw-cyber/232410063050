<?php
include '../config/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = md5($_POST['password']); // Hashing password
    $level = $_POST['level'];

    $query = "INSERT INTO user (Username, Password, Level) VALUES ('$username', '$password', '$level')";

    if (mysqli_query($koneksi, $query)) {
        // Redirect ke halaman user dengan pesan sukses
        header('Location: ../halaman/user.php?pesan=sukses');
        exit; // pastikan script berhenti setelah redirect
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($koneksi);
        exit;
    }
} else {
    header('Location: ../halaman/user.php');
    exit;
}
