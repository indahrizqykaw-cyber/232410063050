<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Aplikasi Kasir</title>

  <!-- Bootstrap 5 CSS -->
  <link rel="stylesheet" href="../assets/css/bootstrap.min.css">

  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    /* Navbar Modern Gradient + Glass Effect */
    .navbar-custom {
      background: linear-gradient(120deg, rgba(93, 122, 237, 0.9), rgba(42, 82, 152, 0.9));
      backdrop-filter: blur(16px);
      -webkit-backdrop-filter: blur(16px);
      border-bottom: 1px solid rgba(255, 255, 255, 0.25);
      box-shadow: 0 4px 24px rgba(0, 0, 0, 0.15);
    }

    /* Brand Logo */
    .navbar-brand img {
      height: 40px;
      margin-right: 10px;
      border-radius: 50%;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
    }

    .navbar-brand-text {
      font-weight: 700;
      font-size: 1.3rem;
      background: linear-gradient(45deg, #1e3c72, #89f7fe);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      letter-spacing: 1px;
    }

    /* Nav Links */
    .navbar-nav .nav-link {
      font-weight: 500;
      color: #bed0faff;
      margin: 0 6px;
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .navbar-nav .nav-link i {
      font-size: 1rem;
    }

    .navbar-nav .nav-link:hover,
    .navbar-nav .nav-link.active {
      color: #fffcfcff;
      transform: translateY(-1px);
    }

    .navbar-nav .nav-link.active {
      font-weight: 600;
      border-bottom: 2px solid #fff;
      border-radius: 2px;
    }

    /* User Info */
    .navbar-user {
      font-weight: 600;
      color: #fff;
      margin-right: 12px;
    }

    /* Logout Button */
    .btn-logout {
      background: linear-gradient(90deg, #89f7fe, #2a5298);
      border: none;
      color: #fff;
      font-weight: 600;
      padding: 6px 16px;
      border-radius: 25px;
      transition: all 0.3s ease;
    }

    .btn-logout:hover {
      background: linear-gradient(90deg, #2a5298, #89f7fe);
      transform: scale(1.05);
    }
  </style>
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-custom sticky-top">
    <div class="container">
      <!-- Brand -->
      <a class="navbar-brand d-flex align-items-center" href="../halaman/dashboard.php">
        <img src="../assets/logo2.png" alt="Logo">
        <span class="navbar-brand-text">Aplikasi Kasir</span>
      </a>

      <!-- Toggle -->
      <button class="navbar-toggler text-white" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <i class="bi bi-list" style="font-size: 1.5rem;"></i>
      </button>

      <!-- Menu -->
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : '' ?>" href="../halaman/dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'penjualan.php' ? 'active' : '' ?>" href="../halaman/penjualan.php"><i class="bi bi-cart-check"></i> Penjualan</a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'produk.php' ? 'active' : '' ?>" href="../halaman/produk.php"><i class="bi bi-box-seam"></i> Produk</a>
          </li>
          <?php if ($_SESSION['Level'] == 'administrator'): ?>
            <li class="nav-item">
              <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'user.php' ? 'active' : '' ?>" href="../halaman/user.php"><i class="bi bi-people"></i> Manajemen User</a>
            </li>
          <?php endif; ?>
        </ul>

        <!-- User Info & Logout -->
        <ul class="navbar-nav ms-auto">
          <li class="nav-item d-flex align-items-center me-2">
            <span class="navbar-user">👋 Halo, <?= htmlspecialchars($_SESSION['Username']); ?>!</span>
          </li>
          <li class="nav-item">
            <a class="btn btn-logout btn-sm" href="../proses/proses_logout.php">
              <i class="bi bi-box-arrow-right"></i> Logout
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <script src="../assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>