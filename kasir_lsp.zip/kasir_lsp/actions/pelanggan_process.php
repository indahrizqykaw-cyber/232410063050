<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: ../index.php");
    exit;
}

require_once '../includes/koneksi.php';

if ($_SESSION['role'] !== 'Administrator') {
    $_SESSION['status_pelanggan'] = "Error: Anda tidak memiliki hak akses untuk memodifikasi data pelanggan.";
    header("Location: ../pages/pelanggan.php");
    exit;
}

$action = $_REQUEST['action'] ?? '';
$status = '';

try {
    // ================= TAMBAH =================
    if ($action == 'tambah') {
        $nama_pelanggan = trim($_POST['nama_pelanggan']);
        $alamat = trim($_POST['alamat']);
        $telepon = trim($_POST['telepon']);
        $jenis_kelamin = trim($_POST['jenis_kelamin']);

        // Handle upload foto (opsional)
        $foto = null;
        if (!empty($_FILES['foto']['name'])) {
            $target_dir = "../uploads/pelanggan/";
            if (!is_dir($target_dir)) {
                mkdir($target_dir, 0777, true);
            }

            $nama_file = time() . "_" . basename($_FILES["foto"]["name"]);
            $target_file = $target_dir . $nama_file;

            $allowed_types = ['image/jpeg', 'image/png', 'image/jpg'];
            if (in_array($_FILES["foto"]["type"], $allowed_types)) {
                if (move_uploaded_file($_FILES["foto"]["tmp_name"], $target_file)) {
                    $foto = $nama_file;
                } else {
                    throw new Exception("Gagal mengunggah foto pelanggan.");
                }
            } else {
                throw new Exception("Tipe file tidak didukung. Gunakan JPG atau PNG.");
            }
        }

        $sql = "INSERT INTO pelanggan (NamaPelanggan, Alamat, NomorTelepon, JenisKelamin, Foto) VALUES (?, ?, ?, ?, ?)";
        $stmt = $koneksi->prepare($sql);
        $stmt->bind_param("sssss", $nama_pelanggan, $alamat, $telepon, $jenis_kelamin, $foto);

        if ($stmt->execute()) {
            $status = "Sukses: Pelanggan '{$nama_pelanggan}' berhasil ditambahkan!";
        } else {
            throw new Exception("Gagal menyimpan data ke database.");
        }
        $stmt->close();
    }

    // ================= EDIT =================
    elseif ($action == 'edit') {
        $id = $_POST['pelanggan_id'];
        $nama_pelanggan = trim($_POST['nama_pelanggan']);
        $alamat = trim($_POST['alamat']);
        $telepon = trim($_POST['telepon']);
        $jenis_kelamin = trim($_POST['jenis_kelamin']);

        // Ambil foto lama
        $foto_lama = null;
        $cek = $koneksi->prepare("SELECT Foto FROM pelanggan WHERE PelangganID = ?");
        $cek->bind_param("i", $id);
        $cek->execute();
        $cek->bind_result($foto_lama);
        $cek->fetch();
        $cek->close();

        // upload foto baru (opsional)
        $foto_baru = $foto_lama;
        if (!empty($_FILES['foto']['name'])) {
            $target_dir = "../uploads/pelanggan/";
            if (!is_dir($target_dir)) {
                mkdir($target_dir, 0777, true);
            }

            $nama_file = time() . "_" . basename($_FILES["foto"]["name"]);
            $target_file = $target_dir . $nama_file;

            $allowed_types = ['image/jpeg', 'image/png', 'image/jpg'];
            if (in_array($_FILES["foto"]["type"], $allowed_types)) {
                if (move_uploaded_file($_FILES["foto"]["tmp_name"], $target_file)) {
                    // Hapus foto lama jika ada
                    if ($foto_lama && file_exists($target_dir . $foto_lama)) {
                        unlink($target_dir . $foto_lama);
                    }
                    $foto_baru = $nama_file;
                } else {
                    throw new Exception("Gagal mengunggah foto baru.");
                }
            } else {
                throw new Exception("Tipe file tidak didukung. Gunakan JPG atau PNG.");
            }
        }

        // Update data pelanggan
        $sql = "UPDATE pelanggan 
                SET NamaPelanggan = ?, Alamat = ?, NomorTelepon = ?, JenisKelamin = ?, Foto = ? 
                WHERE PelangganID = ?";
        $stmt = $koneksi->prepare($sql);
        $stmt->bind_param("sssssi", $nama_pelanggan, $alamat, $telepon, $jenis_kelamin, $foto_baru, $id);

        if ($stmt->execute()) {
            $status = "Sukses: Data pelanggan ID {$id} berhasil diupdate!";
        } else {
            throw new Exception("Gagal mengupdate data pelanggan.");
        }
        $stmt->close();
    }

    // ================= DELETE =================
    elseif ($action == 'delete') {
        $id = $_GET['id'];

        // Cek transaksi
        $cek_transaksi_sql = "SELECT COUNT(*) FROM penjualan WHERE PelangganID = ?";
        $stmt_cek = $koneksi->prepare($cek_transaksi_sql);
        $stmt_cek->bind_param("i", $id);
        $stmt_cek->execute();
        $stmt_cek->bind_result($count);
        $stmt_cek->fetch();
        $stmt_cek->close();

        if ($count > 0) {
            throw new Exception("Pelanggan tidak dapat dihapus karena memiliki riwayat transaksi.");
        }

        // Hapus foto pelanggan (jika ada)
        $foto = null;
        $cek_foto = $koneksi->prepare("SELECT Foto FROM pelanggan WHERE PelangganID = ?");
        $cek_foto->bind_param("i", $id);
        $cek_foto->execute();
        $cek_foto->bind_result($foto);
        $cek_foto->fetch();
        $cek_foto->close();

        if ($foto && file_exists("../uploads/pelanggan/" . $foto)) {
            unlink("../uploads/pelanggan/" . $foto);
        }

        // Hapus data pelanggan
        $sql = "DELETE FROM pelanggan WHERE PelangganID = ?";
        $stmt = $koneksi->prepare($sql);
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            $status = "Sukses: Pelanggan ID {$id} berhasil dihapus!";
        } else {
            throw new Exception("Gagal menghapus pelanggan.");
        }
        $stmt->close();
    }

} catch (Exception $e) {
    $status = "Error: " . $e->getMessage();
}

// Simpan status ke sesi dan kembali ke halaman pelanggan
$_SESSION['status_pelanggan'] = $status;
$koneksi->close();
header("Location: ../pages/pelanggan.php");
exit;
?>