<?php
// Sertakan file header, yang juga akan memulai sesi dan mengecek status login
require_once '../includes/header.php';

// Sertakan koneksi database
require_once '../includes/koneksi.php';

// Cek Pesan Sukses dari Login
if (isset($_SESSION['test_success'])) {
    echo '<div class="alert alert-success">' . $_SESSION['test_success'] . '</div>';
    unset($_SESSION['test_success']); // Hapus agar tidak muncul lagi
}

// Cek Sesi UserID di halaman ini
if (!isset($_SESSION['userid']) || empty($_SESSION['userid']) || $_SESSION['userid'] == 0) {
    echo '<div class="alert alert-danger">
            ERROR: Sesi UserID hilang atau bernilai 0 di halaman Dashboard.
          </div>';
}

// Inisialisasi variabel untuk data dashboard
$total_transaksi = 0;
$total_produk = 0;
$total_pelanggan = 0;

// Logika untuk mengambil data ringkas dari database
// Hanya Administrator yang bisa melihat data keseluruhan
if ($_SESSION['role'] == 'Administrator') {

    // Ambil total transaksi
    $query_transaksi = "SELECT COUNT(*) AS total FROM penjualan";
    $result_transaksi = $koneksi->query($query_transaksi);
    $data_transaksi = $result_transaksi->fetch_assoc();
    $total_transaksi = $data_transaksi['total'];

    // Ambil total produk
    $query_produk = "SELECT COUNT(*) AS total FROM produk";
    $result_produk = $koneksi->query($query_produk);
    $data_produk = $result_produk->fetch_assoc();
    $total_produk = $data_produk['total'];

    // Ambil total pelanggan
    $query_pelanggan = "SELECT COUNT(*) AS total FROM pelanggan";
    $result_pelanggan = $koneksi->query($query_pelanggan);
    $data_pelanggan = $result_pelanggan->fetch_assoc();
    $total_pelanggan = $data_pelanggan['total'];

} else {
    // Petugas hanya melihat total transaksi pribadi

    // Gunakan 0 jika $_SESSION['userid'] tidak terisi, ini mencegah error SQL
    $user_id = isset($_SESSION['userid']) ? $_SESSION['userid'] : 0;

    // Jika UserID 0 atau kosong, kueri akan selalu mengembalikan 0 transaksi, yang aman.
    $query_transaksi = "SELECT COUNT(*) AS total FROM penjualan WHERE UserID = $user_id";
    $result_transaksi = $koneksi->query($query_transaksi);
    $data_transaksi = $result_transaksi->fetch_assoc();
    $total_transaksi = $data_transaksi['total'];
}

// Tutup koneksi database setelah selesai mengambil data
$koneksi->close();
?>

<div class="container-fluid py-4">
    <h4>Selamat Datang, <?php echo $_SESSION['username']; ?>!</h4>
    <p>Anda login sebagai <strong><?php echo $_SESSION['role']; ?></strong>.</p>
    <hr>

    <h1 class="mb-4">Dashboard</h1>

    <div class="row">
        <div class="col-md-4">
            <div class="card text-white bg-primary mb-3">
                <div class="card-body">
                    <h5 class="card-title">Total Transaksi</h5>
                    <p class="card-text fs-2"><?php echo $total_transaksi; ?></p>
                </div>
            </div>
        </div>

        <?php if ($_SESSION['role'] == 'Administrator'): ?>
            <div class="col-md-4">
                <div class="card text-white bg-success mb-3">
                    <div class="card-body">
                        <h5 class="card-title">Total Produk</h5>
                        <p class="card-text fs-2"><?php echo $total_produk; ?></p>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card text-white bg-info mb-3">
                    <div class="card-body">
                        <h5 class="card-title">Total Pelanggan</h5>
                        <p class="card-text fs-2"><?php echo $total_pelanggan; ?></p>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php
// Sertakan file footer
require_once '../includes/footer.php';
?>
