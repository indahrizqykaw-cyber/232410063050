<?php
// Sertakan header (untuk sesi, layout, dan cek login)
require_once '../includes/header.php';

// Sertakan koneksi database
require_once '../includes/koneksi.php';
?>

<H1>Tabel Produk</H1>