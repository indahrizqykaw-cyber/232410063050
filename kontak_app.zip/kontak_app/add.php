<?php
require_once 'db_connect.php';

$nama = $_POST['nama'];
$nomor = $_POST['nomor'];

$sql = "INSERT INTO kontak (nama, nomor) VALUES (?, ?)";
$stmt = $conn->prepare($sql);
$stml->bind_param("ss", $nama, $nomor);

$response = [];

if ($stmt->excute()) {
    $response['status'] = 'success';
    $response['massage'] = 'kontak berhasil ditambahkan';
} else {
    $$response['status'] = 'error';
    $response['massage'] = 'gagal menambahkan kontak';
}

echo json_encode($response);
?>