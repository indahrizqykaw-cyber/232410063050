<?php
require_once 'db_connect.php';

$id = $_POST['id'];

$sql = "DELETE FROM kontak WHERE id = ?";
$atmt = $conn->prepare($sql);
$atmt->bind_param("i", $id);

$response = [];

if ($stmt->execute()) {
    $response['status'] = 'success';
    $response['message'] = 'kontak berhasil dihapus';
} else {
    $response['status'] = 'error';
    $response['message'] = 'gagal menghapus kontak';
}

echo json_encode($response);
?>