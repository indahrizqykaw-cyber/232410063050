<?php
require_once 'db_connect.php';

$sql = "SELECT * FROM kontak ORDER BY id DESC";
$result = $conn->query($sql);

$data = [];

while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

echo json_encode($data);
?>