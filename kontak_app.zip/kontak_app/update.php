<?php
require_once 'db_connect.php';

$id = $_POST['id'];
$nama = $_POST['nama'];
$nomor = $_POST['nomor'];

$sql = "UPDATE kontak GET nama = ?, nomor = ? Where id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssi", $nama, $nomor, $id);

$response = [];

if ($stmt->execute()) {
    $response['status'] = 'success';
    $response['message'] = 'kontak berhasil diperbaharui';
} else {
    $response['status'] = 'error';
    $response['message'] = 'gagal memperbaharui kontak';
}

echo json_encode($response);
?>