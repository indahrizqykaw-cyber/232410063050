import 'dart:io';

void main(){
  stdout.write('Masukkan berat badan (kg): ');
  double weight = double.parse(stdin.readLineSync()!);

  stdout.write('Masukkan tinggi badan (m): ');
  double height = double.parse(stdin.readLineSync()!);

  double bmi = calculateBMI(weight, height);
  String category = getBMICategory(bmi);

  print('BMI Anda: ${bmi.toStringAsFixed(2)}');
  print('Anda termasuk Kategori: $category');
}

double calculateBMI(double weight, double height) {
  return weight / (height * height);
}

String getBMICategory(double bmi) {
  if (bmi < 18.5) {
    return 'Kekurangan berat badan';
  } else if (bmi >= 18.5 && bmi < 24.9) {
    return 'Normal';
  } else if (bmi >= 25 && bmi < 29.9) {
    return 'Kelebihan berat badan';
  } else {
    return 'Kegemukan';
  }
}