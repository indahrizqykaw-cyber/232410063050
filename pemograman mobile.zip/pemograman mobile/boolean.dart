void main(){
    int nilai = 85;
    bool isKriteria = nilai >= 75;

    print('Nilai: $nilai');
    print(isKriteria ? "Lulus" : "Tidak Lulus");
}