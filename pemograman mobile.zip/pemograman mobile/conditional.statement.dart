void main() {
  int usia = 17;

  if (usia >= 13) {
    print("anda masih remaja");
  }else{
    print("anda masih anak-anak");
  }

   String musim = "guludug";

   switch (musim) {
    case "panas":
      print("Jagan lupa pakai sunscreen");
      break;
    case "mendung":
      print("Jagan lupa bawa payung");
      break;
    default:
      print("musim tidak di ketahui");
   }
}