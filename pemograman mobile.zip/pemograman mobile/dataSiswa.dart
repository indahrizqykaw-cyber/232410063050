import 'dart:io';
void main() {
  List<String> dataSiswa = [];

  while (true) {
    // input nama barang
    print('Masukan Nama Siswa (atau ketik "selesai" untuk mengakhiri.): ');
    String namaSiswa = stdin.readLineSync()!;

    // pengecekan jika pengguna ingin mengakhiri program
    if (namaSiswa == "selesai"){
      break;
    }

    // Keterangan input
    dataSiswa.add(namaSiswa);
    print("Nama Siswa $namaSiswa berhasil ditambahkan");

    // Output: menampilkan semua nama siswa
    print("=== DAFTAR SISWA ===");
    if (dataSiswa.isEmpty) {
      print("tidak ada data siswa untuk ditampilkaan!");
    } else {
      for (var siswa in dataSiswa) {
        print("Nama: $siswa");
      }
      print("Total jumlah siswa: ${dataSiswa.length}");
    }
  }
}