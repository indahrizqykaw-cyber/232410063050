import 'dart:io';
void main(){
  List<String> dataSiswa = [];

  while(true){
  //Menu Data Siswa
  print("=== MENU DATA SISWA ===");
  print("1. Tambah Siswa");
  print("2. Tampilkan Semua Siswa");
  print("3. Hapus siswa");
  print("4. Keluar Program");
  print("Silahkan pilih opsi (1-3): ");
  int opsi = int.parse(stdin.readLineSync()!);

  switch (opsi) {
    case 1:
    //Tambah data siswa
    print('Masukkan Nama Siswa: ');
    String namaSiswa = stdin.readLineSync()!;
    dataSiswa.add(namaSiswa);
    print("Siswa $namaSiswa berhasil ditambahkan.");
    break;
    
    case 2:
    //Tampilkan semua siswa
    print("Daftar siswa: ");
     for (int i=0; 1 < dataSiswa.length; i++){
      print("${i + 1}.${dataSiswa[i]}");
    }
    break;

    case 3:
     //Hapus data siswa
    print("Daftar siswa: ");
    for (int i=0; 1 < dataSiswa.length; i++){
      print("${i + 1}.${dataSiswa[i]}");
    }
    stdout.write("Masukkan nomor siswa yang ingin dihapus: ");
    int index = int.parse(stdin.readLineSync()!);
    if (index > 0 && index <= dataSiswa.length){
      print("Siswa atas nama ${dataSiswa[index - 1]} berhasil dihapus.");
      dataSiswa.removeAt(index - 1);
    } else {
      print("Nomor siswa tidak ada");
    }
  
    case 4:
      print("Thank You comay,program selesai.");
      return;

    default:
       print("Opsi tidak valid. Silahkan anda pilih 1, 2, atau 3.");
  }
 }
}