import 'dart:io';

void main() {
// Menghitung gaji karyawan berdasarkan upah per-bulan
// per-jam Rp.85.000
// per-hari 8 jam kerja
// per-minggu 5 hari kerja
// berapa minggu anda berkerja
// gaji anda bulan ini adalah
  stdout.write('Masukan jam kerja anda: ');
  double? jam = double.parse(stdin.readLineSync()!);

  stdout.write('Masukan hari kerja anda: ');
  double? hari = double.parse(stdin.readLineSync()!);

  stdout.write('Masukan minggu anda kerja: ');
  double? minggu = double.parse(stdin.readLineSync()!);

  double gajiSatubulan = 85000 * jam * hari * minggu;

  print('Gaji yang anda dapat selama satu bulan adalah: $gajiSatubulan ');
}
