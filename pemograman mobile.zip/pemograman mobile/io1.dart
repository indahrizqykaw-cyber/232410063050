import 'dart:io';

void main() {
  // output : Meminta user/pengguna memasukan data
  stdout.write('Masukan Nama Anda : ');

  // input : Membaca data yang dimasukan user/pengguna
  String? nama = stdin.readLineSync();

  // output : Menampilkan hasil
  print('Halo, $nama: Selamat Datang Di Pemograman Dart. ');
}