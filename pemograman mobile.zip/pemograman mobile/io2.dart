import 'dart:io';

void main() {
  stdout.write('Masukan angka pertama: ');
  int? angka1 = int.parse(stdin.readLineSync()!);

  stdout.write('Masukan angka kedua: ');
  int? angka2 = int.parse(stdin.readLineSync()!);

  int hasil = angka1 + angka2;
  print('Hasil penjumlahan data diatas adalah: $hasil');
}