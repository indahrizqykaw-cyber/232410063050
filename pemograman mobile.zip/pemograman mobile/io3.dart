import 'dart:io';

void main() {
// Meminta input untuk kondisi benar/salah
stdout.write('Apakah kamu sudah belajar Dart hari ini? (ya/tidak): ');
String? jawaban = stdin.readLineSync();

bool sudahBelajar = jawaban?.toLowerCase() == 'ya';

// Output berdasarkan boolean
if (sudahBelajar) {
  print('Bagus! Tetap semangat belajar.');
} else {
  print('Ayo, jangan lupa untuk belajar Dart hari ini!');
}

}