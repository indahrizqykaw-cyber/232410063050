import 'dart:io';

void main() {
  stdout.write('Berapa kali ingin mencetak pesan?: ');
  int? jumlah = int.parse(stdin.readLineSync()!);

  for (int i = 1; i <= jumlah; i++) {
    print('Ini adalah pesan ke-$i');
  }
}