import 'dart:io';

void main() {
  List<String> namasiswa = [];

  stdout.write('Berapa banyak siswa?: ');
  int? jumlahSiswa = int.parse(stdin.readLineSync()!);

  // Input nama siswa
  for (int i = 0; i < jumlahSiswa; i++) {
    stdout.write('Masukkan nama siswa ke-${i + 1}: ');
    String? nama = stdin.readLineSync();
    namasiswa.add(nama!);
  }

  // Output daftar nama siswa
  print('\nDaftar nama siswa:');
  for (String nama in namasiswa) {
    print(nama);
  }
}