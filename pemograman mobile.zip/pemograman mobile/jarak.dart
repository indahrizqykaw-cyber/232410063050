import 'dart:io';

void main() {
  // // jarak, waktu, kecepatan
  // // rumusnya: jarak = kecepatan * waktu

  // // input kecepatan kendaraan berasarkan (km/jam)
  // stdout.write('Masukan kecepatan kendaraan anda: ');
  // double? kecepatan = double.parse(stdin.readLineSync()!);

  // // input kecepatan kendaraan berasarkan (jam)
  // stdout.write('Masukan waktu tempuh: ');
  // double? waktu = double.parse(stdin.readLineSync()!);

  // // Menghitung jarak tempuh
  // double jarak = kecepatan * waktu;

  // // Menghitung hasil
  // print('jarak tempuh kendaraan anda adalah: $jarak km');


  // //rumusnya: kecepatan = jarak / waktu
  // // input jarak kendaraan berdasarkan (km)
  // stdout.write('Masukan jarak tempuh kendaraan: ');
  // double? jarak = double.parse(stdin.readLineSync()!);

  // stdout.write('Masukan waktu tempuh: ');
  // double? waktu = double.parse(stdin.readLineSync()!);

  // //Menghitung jarak tempuh
  // double kecepatan = jarak / waktu;
  
  // //Menampilkan hasil
  // print('kecepatan kendaraaan anda adalah $kecepatan km/jam');


  //rumusnya: jarak / kecepatan
  // input jarak berdasarkan (km)
  stdout.write('Masukan jarak tempuh kendaraan: ');
  double? jarak = double.parse(stdin.readLineSync()!);

  // input kecepatan kendaraan berdasarkan (km/jam)
  stdout.write('Masukan kecepatan kendaraan: ');
  double? kecepatan = double.parse(stdin.readLineSync()!);

  //Menghitung jarak tempuh
  double waktu = jarak / kecepatan;
  double menit = 60;

  //Menampilkan hasil
  print('waktu yang diperlukan adalah: $waktu jam, atau $menit menit');

}
