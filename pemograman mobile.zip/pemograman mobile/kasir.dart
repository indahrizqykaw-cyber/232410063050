import 'dart:io';
void main(){
  // input nama barang 
  stdout.write('Masukan Nama Barang: ');
  String? namaBarang = stdin.readLineSync();

  // input harga barang 
  stdout.write('Masukan Harga Barang: ');
  double? hargaBarang = double.parse(stdin.readLineSync()!);

  // input jumlah barang yang dibeli
  stdout.write('Masukan Jumlah Barang: ');
  int? jumlahBarang = int.parse(stdin.readLineSync()!);

  // input diskon
  stdout.write('Masukan diskon (dalam %): ');
  double? diskonPersen = double.parse(stdin.readLineSync()!);

  // menghitung total harga
  double totalHarga = hargaBarang * jumlahBarang;
  double diskon = totalHarga * (diskonPersen / 100);
  double ppn = totalHargaDiskon * 0,10;
  double totalHargaAkhir = totalHargaDiskon + ppn;

  // output: menampilkan rincian dan totalharga
  print('=== Struk Pembelian ===');
  print('Nama Barang: $namaBarang');
  print('Harga Barang: Rp, ${hargaBarang.toStringAsFixed(0)}');
  print('Jumlah Barang: $jumlahBarang pcs');
  print('Total Harga setelah Diskon: Rp. ${totalHargaDiskon.toStringAsFixed(0)}');
  print('Total Harga + ppn yang harus dibayar: Rp. ${totalHargaAkhir.toStringAsFixed(0)}');
}