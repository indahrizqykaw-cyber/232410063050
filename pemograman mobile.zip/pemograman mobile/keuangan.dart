import 'dart:io';
void main() {
  print("Masukkan pemasukan: ");
  double pemasukan = double.parse(stdin.readLineSync()!);

  print("Masukkan pengeluaran: ");
  double pengeluaran = double.parse(stdin.readLineSync()!);

  double saldoAkhir = pemasukan - pengeluaran;

  print("Saldo akhir Anda adalah: Rp$saldoAkhir");

}