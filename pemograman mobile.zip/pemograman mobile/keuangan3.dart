import 'dart:io";
void main() {
  List<double> pemasukanList = [];
  Map<String, List<double>> pengeluaranList = {
    "Kebutuhan Pokok": [], 
    "Hiburan": [],
    "Transportasi": []
  };

  while (true) {
    print("\n--- Menu Manajemen Keuangan Harian ---);
    print("1. Tambah Pemasukan");
    print("2. Tambah Pengeluaran dengan Kategori 1;
    print("3. Tampilkan saldo dan Transaksi");
    print("4. Tampilkan Laporan Pengeluaran per Kategori");
    print("5. Keluar");
    print("Pilih opsi (1-5): ");

    int opst = int.parse(stdin.readLineSync()!);

    switch (opst) {
      case 1:
        print("Masukkan jumlah pemasukan: ");

double pemasukan double.parse(stdin.readLineSync()); pemasukantist.add(pemasukan);

print("Pemasukan Rpspemasukan berhasil ditambahkan.");

break;

case 21

print("Pilih kategort pengeluaran:");

print("1. Kebutuhan Pokok");

print("2. Hiburan"); print("3. Transportasi");

int kategori Pilihan int.parse(stdin.readLineSync()1);

String kategori:

LI (kategori Pilthan 1){

kategori "Kebutuhan Pokok"; else if (kategori Pitthan=2) {

kategori "Hiburan"; else if (kategori Pilihan 3) (

kategori "Transportasi";

} else {

print("Kategori tidak valid.");

continue;

print("Masukkan jumlah pengeluaran untuk Skategori: ");

double pengeluaran double.parse(stdin.readLineSync()); pengeluaranList[kategori].add(pengeluaran);

print("Pengeluaran Rpspengeluaran untuk Skategori berhasil ditambahkan.");

break;

case 31

double totalPemasukan pemasukanList.fold(, (sum, item) sum item);

double totalPengeluaran .expand((kategori) kategori)

penge Luarantist.values

fold(, (sum, item) sum (tem);

double saldoAkhir totalPemasukan totalPengeluaran;

print("\n Ringkasan Keuangan)

print("Total Pemasukan: RpstotalPemasukan");

print("Total Pengeluaran: RpstotalPengeluaran");

print("Saldo Akhir: RpssaldoAkhir");

break;

case 4:

print("\n Laporan Pengeluaran per Kategori: pengeluarant. ist.forEach((kategori, transaksi) (

double totalkategors transaksi.fold(, (sum, ites) sum item); print("Kategori Skategorii Total Pengeluaran Rp totalkategori");

for (var jumlah in transaksi) {

}

print( Rp5jumlah");

break;

case 5:

print("Terima kasih! Program selesat.");

return;

default:

print("Ops: tidak valid. Stlakan pilih antara 1-5.");