void main() {
 // string perintah = "lapar";

 // switch (perintah) {
 // case "lapar";
 // print("Jika lapar maka makan");
 // break;
 // case "haus";
 // print("Jika lapar maka minum");
 // break;
 // case "ngantuk";
 // print("Jika lapar maka tidur");
 // break;
 // default;
 // print("mood anda tidak jelas");
 //}



  int nilai = 80;

  if (nilai > 90) {
    print("predikat A");
  } else if (nilai > 80) {
    print("predikat B");
  } else if (nilai > 70) {
    print("predikat C");
  } else if (nilai > 70) {
    print("predikat D");
  } else {
    print("predikat E");
  }
}