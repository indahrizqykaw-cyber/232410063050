import 'dart:io';

void main() {
  // Menghitung Luas, volume Balok
  // stdout.write('Masukan panjang balok: ');
  // double? panjang = double.parse(stdin.readLineSync()!);

  // stdout.write('Masukan lebar balok: ');
  // double? lebar = double.parse(stdin.readLineSync()!);

  // stdout.write('Masukan tinggi balok');
  // double? tinggi = double.parse(stdin.readLineSync()!);

  // double luas = panjang * lebar;
  // double keliling = 2 * (panjang + lebar);
  // double volume = panjang * lebar * tinggi;

  // print('Luas Balok dari data diatas adalah: $luas');
  // print('Keliling Balok dari data diatas adalah: $keliling');
  // print('Volume Balok dari data diatas adalah: $volume');


  // Menghitung Volume Kubus
     stdout.write('Masukan panjang sisi kubus:');
     double? sisi = double.parse(stdin.readLineSync()!);

     double? volume = sisi * sisi * sisi;

     print('Volume Kubus dari tersebut adalah: $volume');


}
