import 'dart:io';
import 'dart:math';
void main() {
// // Volume Silinder
//    double? jariJari = double.parse(stdin.readLineSync()!);

//    stdout.write('Masukan tinggi silinder: ');
//    double? tinggi = double.parse(stdin.readLineSync()!);

//    double volume = pi * jariJari * jariJari * tinggi;

//    print('Volume silinder adalah: $volume');



// MENGHITUNG LUAS DAN KELILING LINGKARANG
// rumus Luas = pi + r * r
// rumus Keliling = 2 * pi * r


// Luas Lingkaran tersebut adalah
  // Keliling Lingkaran tersebut adalah
     stdout.write('Masukan luas linhkaran dan keliling lingkaran: ');
     double? jariJari = double.parse(stdin.readLineSync()!);
 
     double luas = pi * jariJari * jariJari;
     double keliling = 2 * pi * jariJari;

     print('Luas Lingkaran tersebut adalah $luas');
     print('Keliling Lingkaran tersebut adalah $keliling');
} 