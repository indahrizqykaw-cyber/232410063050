void main() {
  int a = 14;
  int b = 3;

  int penjumlahan = a + b;
  int penguranagan = a - b;
  int perkalian = a * b;
  double pembagian = a / b;
  int modulus = a % b;

  print("hasil Pernjumlahan di atas adalah: $penjumlahan");
  print("hasil kurang di atas adalah: $penguranagan");
  print("hasil kali di atas adalah: $perkalian");
  print("hasil pembagian di atas adalah: $pembagian");
  print("hasil bagi di atas adalah: $modulus");

}