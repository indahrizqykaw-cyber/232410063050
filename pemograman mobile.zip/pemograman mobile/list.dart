void main(){
  List <int> Nomer = [76,543,98,32,987,567,132,12,64];
  List <String> buah = ["apel","anggur","pepaya","mangga","durian","strawberry","pisang","pir","melon","lemon","chery"];
  List <String> hp = ["xiomi","redmi","oppo","samsung","huawei","infinix","nokia","tekno","blakberry","vivo","advan","lenovo"];

  print(Nomer[5]);
  print(buah[5]);
  print(hp[5]);
}