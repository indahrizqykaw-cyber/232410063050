void main() {
  int nomor = 10;

  for(int i = 1; i <= nomor; i++) {
    
  }
}