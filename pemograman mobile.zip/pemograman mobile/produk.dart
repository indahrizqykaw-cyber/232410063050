import 'dart:io';

void main() {
  List<String> dataProduk = [];
  while (true) {
    print("1. Tambah Produk");
    print("2. Lihat Produk");
    print("3. Hapus Produk");
    print("4. Cari Produk");
    print("5. Keluar Program");
    stdout.write("Silahkan pilih opsi 1-2-3-4-5:");
    int pilihOpsi = int.parse(stdin.readLineSync()!);

    switch(pilihOpsi) {
      case 1:
        stdout.write("Masukan Nama Produk: ");
        String produk = stdin.readLineSync()!; 
        dataProduk.add(produk);  
        print("Produk $produk berhasil ditambahkan");
        break;
      case 2:
        print("Hapus Produk: ");
        for (int i = 0; i < dataProduk.length; i++) {
          print("{$i+}.${dataProduk[i]}");
        }
        break;
      case 3:
        print("Data Produk: ");
        for (int i = 0; i < dataProduk.length; i++) {
          print("{$i+}.${dataProduk[i]}");
        }
        stdout.write("Masukan nomor produk yang akan dihapus: ");
        int noHapus = int.parse(stdin.readLineSync()!);
        if (noHapus > 0 && noHapus <= dataProduk.length) {
          print("Produk ${dataProduk[noHapus - 1]} berhasil dihapus");
          dataProduk.removeAt(noHapus - 1);
        } else {
          print("Nomor produk tidak ada.");
        }
      case 4:
        stdout.write("Masukan nomor produk yang ingin di cari: ");
        String queryProduk = stdin.readLineSync()!;
        List<String> cariProduk =
          dataProduk.where((produk) => produk.contains(queryProduk)).toList();
     
        if(cariProduk.isEmpty) {
          print("Produk tidak ditemukan.");
        } else {
          print("Hasil pencarian: ");
          for (var produk in cariProduk) {
            print("- $produk");
          }
        }
        break;
      case 5:
        print ("Terima kasih Program Selesai.");
        return;
    }
  }
}