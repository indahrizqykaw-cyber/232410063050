void main() {
  String nama = "indah";
  String sapa = "hallo, $nama!";


  print("$sapa");
}