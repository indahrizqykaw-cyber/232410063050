void main() {
  int umur = 18;
  bool isBolehNonton = umur >= 17;

print('Umur Anda: $umur');
  print(isBolehNonton ? 'Boleh Nonton Drakor dikarnakan sudah cukup umur' : 'Tidak boleh Nonton Drakor dikarnakan belum cukup umur');
}