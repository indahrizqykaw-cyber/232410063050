void main() {
  String NamaDepan = 'indah';
  String NamaBelakang = 'Rizqyka Wulandari';
  int Umur = 16;
  String NamaLengkap = '$NamaDepan $NamaBelakang Umur Saya $Umur tahun';

  print('Nama Saya dan Umur Saya: $NamaLengkap');
}