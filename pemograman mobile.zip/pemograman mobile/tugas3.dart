void main() {
  String kondisonal='ngantuk';

  switch (kondisonal) {
  case 'makan':
    print('kalo lapar makan');
    break;
  case 'minum':
    print('kalo haus minum');
    break;
  case 'ngantuk':
    print('kalo ngantuk tidur');
    break;
    default:
    print('tidak di ketahui');
  }
}