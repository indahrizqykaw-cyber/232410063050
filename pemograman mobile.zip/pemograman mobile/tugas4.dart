void main(){
  int usia = 1000;

  if (usia <= 5){
    print('anda berada dalam periode balita');
  } else if (usia <= 14){
    print('anda berada dalam periode anak-anak');
  } else if (usia <= 25){
    print('anda berada dalam periode remaja');
  } else if (usia <= 45){
    print('anda berada dalam periode dewasa');
  } else {
    print('SESEPUH');
  }
}